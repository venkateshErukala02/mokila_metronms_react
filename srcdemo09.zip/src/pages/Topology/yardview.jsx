import React from "react";


const YardView=({textName})=>{


    return(
        <>
        
        </>
    )
}

export default YardView;