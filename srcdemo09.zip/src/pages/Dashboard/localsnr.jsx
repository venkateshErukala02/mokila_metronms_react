// import React from "react";

// const LocalSnr=()=>{
//     return(
//         <div class="col-md-6 boxmonitor1" style={{backgroundColor:'aliceblue',margin:'auto'}}>
//         <div class="row" style={{marginRight:'0px', flexWrap:"nowrap",height:'25vh'}}>
//           <div class="col-md-12" style={{ paddingLeft: "20px" }}>
//             <iframe
//               class="chartjs-hidden-iframe"
//               tabindex="-1"
//               style={{display:'block',overflow:'hidden',border:'0px', margin:'0px', inset:'0px',height:'100%',width:'100%', position:'absolute',pointerEvents:'none',zIndex:'-1'}}
//             ></iframe>
//             <canvas
//               id="link_char3"
//               style={{ display: "block", width: "874px", height: "127px" }}
//             ></canvas>
//           </div>
//         </div>
//       </div>
//     )
// }
// export default LocalSnr;



import React, { useEffect, useRef } from "react";
import Chart from "chart.js/auto";

const LocalSnr = () => {
  const canvasRef = useRef(null);
  let chartInstance = useRef(null);

  useEffect(() => {
    const ctx = canvasRef.current.getContext("2d");

    if (chartInstance.current) {
      chartInstance.current.destroy(); // Clean up previous chart
    }

    chartInstance.current = new Chart(ctx, {
      type: "line",
      data: {
        labels: ["Mon", "Tue", "Wed", "Thu", "Fri"],
        datasets: [
          {
            label: "SNR",
            data: [20, 25, 18, 22, 27],
            borderColor: "#3e95cd",
            fill: false,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, []);

  return (
    

    <div class="col-md-6 boxmonitor1"  style={{marginLeft:'11px',width: "670px", height: "240px"}}>
    <div class="row" style={{marginRight:'0px', flexWrap:"nowrap",height:'25vh'}}>
      <div class="col-md-12" style={{ paddingLeft: "20px" }}>
        <canvas ref={canvasRef}
          id="link_char3"
          style={{ display: "block", width: "874px", height: "127px" }}
        ></canvas>
      </div>
    </div>
  </div>
    
  );
};

export default LocalSnr;
