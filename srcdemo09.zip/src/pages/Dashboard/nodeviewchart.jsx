// import React, { useState,useEffect } from 'react';
// // import { Line } from 'react-chartjs-2';
// // import {
// //     Chart,
// //     CategoryScale,
// //     LinearScale,
// //     BarElement,
// //     LineElement,
// //     PointElement,
// //     Tooltip,
// //     Legend
// //   } from 'chart.js';

// //   Chart.register(
// //     CategoryScale,
// //     LinearScale,
// //     BarElement,
// //     LineElement,
// //     PointElement,
// //     Tooltip,
// //     Legend
// //   );

//   import { AreaChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// const NetworkMonitoringDashboard = ({nodeDataId}) => {
// //   const [timeRange, setTimeRange] = useState('1 Month');
// //   const [showLatency, setShowLatency] = useState(false);
// //   const [ctx,config]=useState('')
// //   if (window.myChart) {
// //     window.myChart.destroy();
// //   }
// //   window.myChart = new Chart(ctx, config);

// //   const handleTimeRangeChange = (range) => {
// //     setTimeRange(range);
// //     // Fetch and update chart data based on the selected time range
// //   };

// //   const toggleMetric = () => {
// //     setShowLatency((prev) => !prev);
// //     // Toggle between throughput and latency data
// //   };

// //   const chartData = {
// //     // Define your chart data here
// //     labels: [], // e.g., time labels
// //     datasets: [
// //       {
// //         label: showLatency ? 'Latency (ms)' : 'Throughput (Mbps)',
// //         data: [], // e.g., metric values
// //         borderColor: 'rgba(75,192,192,1)',
// //         fill: false,
// //       },
// //     ],
// //   };

// const [isLoading, setIsLoading] = useState("");
// const [isError, setIsError] = useState("");
// const [gpItemDt, setGpItemDt] = useState([]);

// // console.log("frtygbjhfnksmfkl", nodeDataId);
// // console.log("srinivas", count);

// const getServerStatusDt = async (url) => {
//   setIsLoading(true);
//   setIsError({ status: false, msg: "" });
//   try {
//     const username = "admin";
//     const password = "admin";
//     const token = btoa(`${username}:${password}`);
//     const options = {
//       method: "GET",
//       headers: {
//         Authorization: `Basic ${token}`,
//         "Content-Type": "application/json",
//       },
//     };
//     const response = await fetch(url, options);
//     const data = await response.json();

//     if (response.ok) {
//       setIsLoading(false);
//       setGpItemDt(data);
//       console.log("Fetched server status:", data);
//       setIsError({ status: false, msg: "" });
//     } else {
//       throw new Error("Data not found");
//     }
//   } catch (error) {
//     setIsLoading(false);
//     setIsError({ status: true, msg: error.message });
//     console.error("Fetch error:", error);
//   }
// };

// useEffect(() => {
//   const fetchData = async () => {
//     let url = 'http://192.168.66.26:8980/ornms/api/v2/nodelinks/wirelessstats?nodeId=1';
//     await getServerStatusDt(url);
//   };
//   fetchData();
// }, []);

//   const chartDataNew = gpItemDt.links
//   .map((link, index) => ({
//       name: `${3 - index}m`,  // This will create names like '3m', '2m', '1m'
//       throughputIn: parseFloat(link.throughputIn),
//       throughputOut: parseFloat(link.throughputOut),
//       throughputtotal: parseFloat(link.throughputIn) + parseFloat(link.throughputOut)
//   }))
//   .reverse();  // Now we can safely reverse the array after mapping

//   return (
//     // <div className="dashboard-container">
//     //   <div className="controls">
//     //     <div className="time-range-buttons">
//     //       {['Live', '1 Hour', '1 Day', '1 Week', '1 Month'].map((range) => (
//     //         <button
//     //           key={range}
//     //           className={timeRange === range ? 'active' : ''}
//     //           onClick={() => handleTimeRangeChange(range)}
//     //         >
//     //           {range}
//     //         </button>
//     //       ))}
//     //     </div>
//     //     <div className="metric-toggle">
//     //       <label>Throughput (Mbps)</label>
//     //       <input
//     //         type="checkbox"
//     //         checked={showLatency}
//     //         onChange={toggleMetric}
//     //       />
//     //       <label>Latency (ms)</label>
//     //     </div>
//     //   </div>
//     //   <div className="chart-container">
//     //     <Line data={chartData} />
//     //   </div>
//     // </div>

//     <article style={{ width: "450px", height: "240px" }}>
//     <ResponsiveContainer width="100%" height={240}>
//         <AreaChart data={chartDataNew}>
//             <CartesianGrid strokeDasharray="3 3" />
//             <XAxis dataKey="name" reversed fontFamily='Lato-Regular' letterSpacing='0.2px'
//             />
//             <YAxis ticks={[0, 0.1, 0.2, 0.3, 0.4, 0.5]} />
//             <Tooltip />
//             {/* <Legend /> */}
//             <Area type="monotone" dataKey="throughputIn" stroke="#3fc5e1c4" fill="#569de3" fontFamily='Lato-Regular' letterSpacing='0.2px' />
//             <Area type="monotone" dataKey="throughputOut" stroke="#82ca9d" fill="#58cce5" fontFamily='Lato-Regular' letterSpacing='0.2px' />
//             <Area type="monotone" dataKey="throughputtotal" stroke="#82ca9d" fill="#b299cc" fontFamily='Lato-Regular' letterSpacing='0.2px' />

//             <Line type="monotone" dataKey="throughputOut" stroke="#82ca9d" fontFamily='Lato-Regular' letterSpacing='0.2px' />
//         </AreaChart>
//     </ResponsiveContainer>
// </article>
//   );
// };

// export default NetworkMonitoringDashboard;

import React, { useState, useEffect } from "react";
import LocalRssl from "./localrssi";
import LocalSnr from "./localsnr";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Line,
} from "recharts";

const NetworkMonitoringDashboard = ({ nodeDataId }) => {
  const [gpItemDt, setGpItemDt] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState({ status: false, msg: "" });

  //   const getServerStatusDt = async (url) => {
  //     setIsLoading(true);
  //     setIsError({ status: false, msg: "" });
  //     try {
  //       const username = "admin";
  //       const password = "admin";
  //       const token = btoa(`${username}:${password}`);
  //       const options = {
  //         method: "GET",
  //         headers: {
  //           "Authorization": `Basic ${token}`,
  //           "Content-Type": "application/json",
  //            "Cache-Control": "no-cache"
  //         },
  //       };
  //       const response = await fetch(url, options);
  //       const data = await response.json();

  //       if (response.ok) {
  //         setGpItemDt(data);
  //       } else {
  //         throw new Error("Data not found");
  //       }
  //     } catch (error) {
  //       setIsError({ status: true, msg: error.message });
  //       console.error("Fetch error:", error);
  //     } finally {
  //       setIsLoading(false);
  //     }
  //   };

  const getServerStatusDt = async (url) => {
    setIsLoading(true);
    setIsError({ status: false, msg: "" });
    try {
      const username = "admin";
      const password = "admin";
      const token = btoa(`${username}:${password}`);
      const options = {
        method: "GET",
        headers: {
          Authorization: `Basic ${token}`,
          "Content-Type": "application/json",
          "Cache-Control": "no-cache",
        },
      };

      const response = await fetch(url, options);

      if (response.status === 200) {
        const data = await response.text();
        setGpItemDt(data);
      } else if (response.status === 304) {
        console.log("304 Not Modified – using cached data.");
      } else {
        throw new Error(`Unexpected response: ${response.status}`);
      }
    } catch (error) {
      setIsError({ status: true, msg: error.message });
      console.error("Fetch error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      const url = `api/v2/nodelinks/ping?nodeId=${nodeDataId}`;
      await getServerStatusDt(url);
    };
    fetchData();
  }, [nodeDataId]);

  const data = [];

  const chartDataNew = (gpItemDt.links || [])
    .map((link, index) => ({
      name: `${3 - index}m`,
      throughputIn: parseFloat(link.throughputIn || 0),
      throughputOut: parseFloat(link.throughputOut || 0),
      throughputtotal:
        parseFloat(link.throughputIn || 0) +
        parseFloat(link.throughputOut || 0),
    }))
    .reverse();

  return (
    <>
      <div>
        {/* {isError.status && <p style={{ color: 'red' }}>{isError.msg}</p>} */}
        {isLoading ? (
          <p>Loading...</p>
        ) : (
          <article style={{ width: "650px", height: "240px" }}>
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="name"
                  reversed
                  fontFamily="Lato-Regular"
                  letterSpacing="0.2px"
                />
                <YAxis ticks={[0, 0.1, 0.2, 0.3, 0.4, 0.5]} />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="throughputIn"
                  stroke="#3fc5e1c4"
                  fill="#569de3"
                />
                <Area
                  type="monotone"
                  dataKey="throughputOut"
                  stroke="#82ca9d"
                  fill="#58cce5"
                />
                <Area
                  type="monotone"
                  dataKey="throughputtotal"
                  stroke="#8884d8"
                  fill="#b299cc"
                />
                <Line
                  type="monotone"
                  dataKey="throughputOut"
                  stroke="#82ca9d"
                />
              </AreaChart>
            </ResponsiveContainer>
          </article>
        )}
      </div>

      <article >
        <LocalRssl/>
      </article>

      <article>
        <LocalSnr/>
      </article>


     
    </>
  );
};

export default NetworkMonitoringDashboard;
