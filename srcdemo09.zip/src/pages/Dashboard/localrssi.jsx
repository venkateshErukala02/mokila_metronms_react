// import React from "react";

// const LocalRssl = () => {
//   return (
//     <div className="col-md-6 boxmonitor1">
//       <div
//         className="row"
//         style={{
//           marginRight: "0px",
//           flexWrap: "nowrap",
//           height: "25vh",
//         }}
//       >
//         <div
//           className="col-md-12"
//           style={{ paddingLeft: "20px", position: "relative" }}
//         >
//           {/* Normally injected automatically by Chart.js, included here if needed */}
//           <iframe
//             title="chart-hidden-frame"
//             className="chartjs-hidden-iframe"
//             tabIndex="-1"
//             style={{
//               display: "block",
//               overflow: "hidden",
//               border: "0px",
//               margin: "0px",
//               inset: "0px",
//               height: "100%",
//               width: "100%",
//               position: "absolute",
//               pointerEvents: "none",
//               zIndex: "-1",
//             }}
//           ></iframe>

//           <canvas
//             id="link_char1"
//             style={{ display: "block", width: "874px", height: "127px" }}
//             width="874"
//             height="127"
//           ></canvas>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default LocalRssl;



import React, { useEffect, useRef } from "react";
import { Chart } from "chart.js/auto";

const LocalRssl = () => {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const ctx = canvasRef.current.getContext("2d");

    // Create a sample line chart
    const myChart = new Chart(ctx, {
      type: "line",
      data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
        datasets: [
          {
            label: "RSSI Value",
            data: [12, 19, 3, 5, 2, 3],
            fill: false,
            borderColor: "rgb(75, 192, 192)",
            tension: 0.1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
      },
    });

    // Cleanup chart instance on unmount
    return () => {
      myChart.destroy();
    };
  }, []);

  return (
    <div className="col-md-6 boxmonitor1" style={{width: "670px", height: "240px", marginLeft:'11px'}}>
      <div
        className="row"
        style={{
          marginRight: "0px",
          flexWrap: "nowrap",
          height: "100%",
        }}
      >
        <div
          className="col-md-12"
          style={{ paddingLeft: "20px", position: "relative", height: "100%" }}
        >
          <canvas
            ref={canvasRef}
            id="link_char1"
            style={{ display: "block", width: "100%", height: "100%" }}
          />
        </div>
      </div>
    </div>
  );
};

export default LocalRssl;

