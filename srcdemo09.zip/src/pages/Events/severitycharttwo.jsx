import React, { useState,useEffect } from "react";
 import '../ornms.css';
import { BarChart, Bar, XAxis, YAxis,Line, Tooltip, ResponsiveContainer, Cell, CartesianGrid } from "recharts";
import './../Events/events.css';

// const datastring = {"category":{"Down":0,"Associated":0,"DyingGasp":0,"Up":0,"DisAssociated":0}}



const   SeverChartone = () => {
  const [activeIndex, setActiveIndex] = useState(null);

   const [categoryData, setCategoryData] = useState('');
        const [isLoading, setIsLoading] = useState(false);
        const [isError, setIsError] = useState({ status: false, msg: "" });
    
    
        const getDataCategory = async () => {
            setIsLoading(true);
            setIsError({ status: false, msg: "" });
            try {
    
               const url='api/v2/events/catgraph?_s=eventDisplay%3D%3DY;eventCreateTime%3Dgt%3D1743139063249&ar=glob' 
              
    
                const options = {
                    method: "GET",
                   
                };
                const response = await fetch(url, options);
    
                const data = await response.json();
               
  
  
    
                if (response.ok) {
                    setIsLoading(false);
                    setCategoryData(data.category);
                    setIsError({ status: false, msg: "" });
                } else {
                    throw new Error("data not found");
                }
            } catch (error) {
                setIsLoading(false);
                setIsError({ status: true, msg: error.message });
            }
        };
    
        useEffect(() => {
          getDataCategory();
        }, []);

        const customOrderf = ["Up", "Down", "Associated", "DisAssociated", "DyingGasp"];

        const dataobj = categoryData;


const sortedData = customOrderf.map(key => ({
    name: key.charAt(0).toUpperCase() + key.slice(1),  
    displayValue: dataobj[key] === 0 ? 0.01 : dataobj[key]  
  }));

  
  // const data = Object.keys(dataobj).map(key => ({
  //   name: key.charAt(0).toUpperCase() + key.slice(1),
  //   value: dataobj[key],
  //   displayValue: dataobj[key] === 0 ? 0.01 : dataobj[key]
  // }));

  // console.log('dddd',data)

const CustomTooltip = ({ payload, label, active }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip" style={{ backgroundColor: 'white', padding: '10px', border: '1px solid #ccc', minWidth: '50px' }}>
        <p style={{ padding: '0', margin: '0' }}>{label}</p>
        <p style={{ margin: '0', padding: '0' }}>{`Value: ${payload[0].value === 0.01   ? 0 : payload[0].value}`}</p>
      </div>
    );
  }
  return null;
};
  

  const handleMouseEnter = (index) => {
    setActiveIndex(index);
  };

  const handleMouseLeave = () => {
    setActiveIndex(null);
  };


  const getColor = (name) => {
    switch (name) {
      case 'Up':
        return "#FF0000"; // Red
      case 'Down':
        return "#FF7F00"; // Orange
      case 'Associated':
        return "#FFD700"; // Yellow
      case 'DisAssociated':
        return "#FFA500"; // Light Orange
      case 'DyingGasp':
        return "#008000"; // Green
      default:
        return "#8884d8"; // Default color
    }
  };

  return (
    <section className="">
      <div className="">
        <div className="categorytitle">Category Chart for Global for 24 hours</div>
        <ResponsiveContainer width="100%" height={185}>
          <BarChart data={sortedData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
            <CartesianGrid stroke="#ccc" strokeWidth={0.4}  vertical={true}/>

            <XAxis
              dataKey="name"
              tickLine={{ strokeWidth: 0 }}
              axisLine={{ stroke: 'black', strokeWidth: 0.1 }}
              tick={{ fill: '#0000008A', fontSize: '12px', fontWeight: 'bold', fontFamily: 'Lato-Regular',letterSpacing:'0.2px'  }}
            />

            <YAxis
              domain={[0, 1]}
              ticks={[0,0.2,0.4,0.6,0.8,1.0]}
              tickLine={{ strokeWidth: 0.4, stroke: '#ccc' }}
              axisLine={{ stroke: '#ccc', strokeWidth: 0.1 }}
              tick={{ fill: '#0000008A', fontSize: '12px', fontFamily: 'Lato-Regular',letterSpacing:'0.2px'  }}
             tickFormatter={(tick) => tick === 0 ? "0" : tick.toFixed(1)}
            />

            <Tooltip content={<CustomTooltip />} wrapperStyle={{
              padding: '10px',
            }} cursor={{ fill: 'transparent' }} />

            <Bar dataKey="displayValue" fill="#8884d8" barSize={30}
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
              radius={[0, 0, 0, 0]}
              opacity={activeIndex !== null ? 1 : 1}
              activeFill="red">
              {sortedData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={getColor(entry.name)}

                />
              ))}
            </Bar>
            {sortedData.map((entry, index) => (
              <Line
                key={`line-${index}`}
                type="monotone"
                data={[{ name: entry.name, value: entry.value }]}
                dataKey="value"
                stroke="green"
                strokeWidth={5}
                dot={true} // Remove dots
                isAnimationActive={true} // Remove animation for the lines
                activeDot={{ r: 0 }}
              />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
};

export default SeverChartone;
