import React from 'react';
import ReactDOM from 'react-dom/client';
// import { BrowserRouter } from 'react-router-dom';
import "./inde.css";
import RoutesPage from './Routes/routepage';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import { Provider } from 'react-redux';
import store from './pages/Store/store';


const root = ReactDOM.createRoot(document.getElementById('root'));
 root.render(
   <Provider store={store}>
    {/* <React.StrictMode> */}
    {/* <BrowserRouter> */}
       <RoutesPage />
    {/* </BrowserRouter> */}
 {/* </React.StrictMode> */}
 </Provider>

    );

 
//  root.render(<UserContextProvider>
//     <SubChildContext/>
//  </UserContextProvider>);


// setInterval(()=>{
//   root.render(<Appo />);

// },1000)
