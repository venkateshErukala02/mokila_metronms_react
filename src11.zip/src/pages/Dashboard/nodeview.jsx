import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { useDispatch } from 'react-redux';
import { handleNodeData } from "../Action/action";
import "../ornms.css";
import LeftNavList from "../Navbar/leftnavpage";
import SummaryTab from "./summarytab";
import EventTab from "./eventstab";

const NodeDetails = () => {
  const [isLoading, setIsLoading] = useState("");
  const [isError, setIsError] = useState("");
  
  const count = useSelector((state) => state);
  const isVisible = useSelector((state) => state.visibility.isVisible);
  const [currentTab,setCurrentTab] = useState('summary')
        const [nodeItemDt, setNodeItemDt] = useState([]);
       
        const nodeDataId = useSelector((state) => state.node.node.nodeId);
            const nodeIpaddress = useSelector((state) => state.node.node.ipAddress);
    console.log('ghjjjjj',nodeDataId);
    
 const getServerStatusDt = async (url) => {
    setIsLoading(true);
    setIsError({ status: false, msg: "" });
    try {
      const username = "admin";
      const password = "admin";
      const token = btoa(`${username}:${password}`);
      const options = {
        method: "GET",
        headers: {
          "Authorization": `Basic ${token}`,   
          "Content-Type": "application/json",
        },
      };
      const response = await fetch(url,options);
      const data = await response.json();

      if (response.ok) {
        setIsLoading(false);
        
        
        setNodeItemDt(data);
        console.log("Fetched server status:", data);
        setIsError({ status: false, msg: "" });
      } else {
        throw new Error("Data not found");
      }
    } catch (error) {
      setIsLoading(false);
      setIsError({ status: true, msg: error.message });
      console.error("Fetch error:", error);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      console.log('ppkkpp',localStorage.getItem('nodeId'));
      const nodeId = localStorage.getItem('nodeId');
      let url = `http://localhost:8980/metronms/api/v2/nodemanageview/summarydb?nodeId=${nodeId}`;
      await getServerStatusDt(url);
    };
    fetchData();
  }, [nodeDataId]);

  useEffect(()=>{
    if(nodeDataId){
      localStorage.setItem('nodeId',nodeDataId);

    }
  },[nodeDataId]);

  useEffect(()=>{
    if(nodeIpaddress){
      localStorage.setItem('nodeIpaddress',nodeIpaddress);

    }
  },[nodeIpaddress]);





  const navigate = useNavigate();
  const dispatch = useDispatch();
 
    
  // const handleRowClick = () => {
  //               navigate('/node-event', { state: { nodeItemDt } });
  //               dispatch(handleNodeData(nodeItemDt))
  //               };


  const handleRowClick=(value)=>{
    setCurrentTab(value);
  }


  const renderCurrentTab=(value)=>{
    switch (value) {
      case 'summary':
       return <SummaryTab nodeItemDt={nodeItemDt}/>
        break;
        case 'events':
          return <EventTab/>
          break;
    
      default:
        break;
    }
  }
  
  


  return (
    <>
      <section className="display-f">
        <article
          className={isVisible ? "leftsidebardisblock" : "leftsidebardisnone"}
        >
          <LeftNavList className="leftsidebar"/>
        </article>
        <article className="container-fluid">
          <article className="row boxsizeng">
            <article className="col-md-12" style={{ paddingRight: 0 }}>

            <ul className="nodelist">
              <li>Node View</li>
              <li>Customer... <span> {nodeItemDt.ipAddress}</span></li>
              <li onClick={() => handleRowClick('summary')}>  <i className="fas fa-lg fa-grip-vertical Summary-icon"></i>Summary</li>
              <li onClick={() => handleRowClick('events')}><i
                      className="fas fa-chart-area Monitor-icon"
                      style={{ fontSize: "22px" }}
                    ></i> Events</li>
            </ul>
              {/* <article className="row ">
                <article style={{ width: "100%", marginTop: "4px" }}>
                  <article>
                    <article style={{ display: "flex" }}>
                      <article
                        style={{
                          width: "50%",
                          textAlign: "center",
                          marginTop: "11px",
                        }}
                      >
                        <h2 className="nodeview-nav fontsize-22">
                          &nbsp;&nbsp;Node View
                        </h2>
                      </article>
                      <article style={{ width: "50%", textAlign: "left" }}>
                        <span className="navCpu">
                          <span
                            style={{
                              display: "block",
                              padding: "0px 10px",
                              height: "41px",
                              marginTop: "3px",
                              borderLeft: "1px solid #c0c0c0",
                            }}
                          >
                            <article>
                              <label className="label-CpuMemoryTemp">
                                Customer ...
                              </label>
                              <article
                                className="label-CpuMemoryTemp"
                                style={{ fontSize: "14px" }}
                              >
                              {nodeItemDt.ipAddress}
                              </article>
                            </article>
                          </span>
                        </span>
                      </article>
                    </article>
                  </article>
                </article>
              </article>
            </article>

            <article className="col-md-10" style={{ marginTop: "4px" }}>
              <nav className="">
                <span id="my-contentsmall">
                  <span className="Summary">
                    <i className="fas fa-lg fa-grip-vertical Summary-icon"></i>
                    <label className="summarylable" onClick={() => handleRowClick('summary')}
                     style={{ cursor: 'pointer',color:'rgb(73, 80, 87)',borderTop: currentTab === 'summary' ? '3px solid #639' : 'none',paddingTop: '5px',display: 'inline-block'}}>
                      Summary</label>
                  </span>


                  <span
                    className="Monitor Monitor-2"
                    style={{ padding: "5px" }}
                  >
                    <i
                      className="fas fa-chart-area Monitor-icon"
                      style={{ fontSize: "22px" }}
                    ></i>
                      <label className="summarylable" onClick={() => handleRowClick('events')}
                    style={{ cursor: 'pointer',color:'rgb(73, 80, 87)',  borderTop: currentTab === 'events' ? '3px solid  #639' : 'none',paddingTop: '5px',display: 'inline-block' }}>Events</label>
                
                  </span>


                </span>
              </nav>
            </article> */}
          </article>
          </article>
          
          {renderCurrentTab(currentTab)}

          {/* <article className="row">
            <article
              className="col-md-12"
              style={{ padding: "10px", backgroundColor: "#cccccc" }}
            >
              
                           <article  className="container-fluid">
                           <article className="row" style={{ display: "flex" }}>
                             <article className="col-md-2" id="summary-1 div1">
                               <article>
                                 
                                 <article className="card" id="div2">
                                   <article style={{ margin: "auto" }}>
                                     <img className="nodeimg" src={nodeimage} alt="node" />
                                   </article>
                                   <article style={{ margin: "auto" }}>
                                     <article>
                                       <article style={{ margin: "auto" }}>
                                         <article>
                                           <article>
                                             <article className="sidetb1td">
                                               <article>
                                                 <label style={{ textAlign: "center" }}>
                                                   <label className="summarymode">
                                                   {nodeItemDt.nodeDesc} 
                                                   </label>
                                                   <br />
                                                   <label className="summarysytem">
                                                     <i class="fas fa-arrow-up fa-1x ng-scope "></i>
                                                     {nodeItemDt.uptime} 
                                                   </label>
                                                   <br />
                                              
                                                 </label>
                                               </article>
                                             </article>
                                           </article>
                                         </article>
                                       </article>
                                     </article>
                                     <article className="tableres">
                                       <article style={{ margin: "auto" }}>
                                         <article>
                                           <article>
                                             <article className="sidebar2">
                                               <article style={{ display: "flex" }}>
                                                 <img
                                                   src={radioimage}
                                                   alt=""
                                                   style={{ marginRight: "6px" }}
                                                 />
                                                 <span style={{ textAlign: "left" }}>
                                                   <label className="radiolable">
                                                     Radio Mode
                                                   </label>
                                                   <br />
                                                   <span className="outdoor">
                                                   {nodeItemDt.radioMode} 
                                                   </span>
                                                 </span>
                                               </article>
                                             </article>
                                           </article>
                                           <article>
                                             <article className="sidebar2">
                                               <article style={{ display: "flex" }}>
                                                 <img
                                                   src={ptmplinkimage}
                                                   alt="PTMP"
                                                   style={{ marginRight: "6px" }}
                                                 />
                                                 <span style={{ textAlign: "left" }}>
                                                   <label className="radiolable">
                                                     Link Type
                                                   </label>
                                                   <br />
                                                   <span className="outdoor">{nodeItemDt[0]?.linkType}</span>
                                                 </span>
                                               </article>
                                             </article>
                                           </article>
                                           <article>
                                             <article className="sidebar2">
                                               <article style={{ display: "flex" }}>
                                                 <i
                                                   className="hardwareversionicon"
                                                   style={{ marginRight: "6px" }}
                                                 ></i>
                                                 <span style={{ textAlign: "left" }}>
                                                   <label className="radiolable">
                                                     Hardware Version
                                                   </label>
                                                   <br />
                                                   <span className="outdoor">{nodeItemDt.hardwareVersion} </span>
                                                 </span>
                                               </article>
                                             </article>
                                           </article>
                                           <article>
                                             <article className="sidebar2">
                                               <article style={{ display: "flex" }}>
                                                 <img
                                                   src={bootloader}
                                                   alt=""
                                                   style={{
                                                     width: "35px",
                                                     height: "35px",
                                                     marginRight: "6px",
                                                   }}
                                                 />
                                                 <span style={{ textAlign: "left" }}>
                                                   <label className="radiolable">
                                                     Bootloader Version
                                                   </label>
                                                   <br />
                                                   <span className="outdoor">{nodeItemDt.softwareVersion} </span>
                                                 </span>
                                               </article>
                                             </article>
                                           </article>
                                           <article>
                                             <article className="sidebar2">
                                               <article style={{ display: "flex" }}>
                                                 <i
                                                   className="serialnumbericon"
                                                   style={{ marginRight: "6px" }}
                                                 ></i>
                                                 <span style={{ textAlign: "left" }}>
                                                   <label className="radiolable">
                                                     Serial Number
                                                   </label>
                                                   <br />
                                                   <span className="outdoor">
                                                   {nodeItemDt.serialNumber}
                                                   </span>
                                                 </span>
                                               </article>
                                             </article>
                                           </article>
                                           <article>
                                             <article className="sidebar2">
                                               <article style={{ display: "flex" }}>
                                                 <i
                                                   className="firmwareicon"
                                                   style={{ marginRight: "6px" }}
                                                 ></i>
                                                 <span style={{ textAlign: "left" }}>
                                                   <label className="radiolable">
                                                     Firmware
                                                   </label>
                                                   <br/>
                                                   <span className="outdoor">
                                                   {nodeItemDt.softwareVersion}
                                                   </span>
                                                 </span>
                                               </article>
                                             </article>
                                           </article>
                                           <article>
                                             <article className="sidebar2">
                                               <article style={{ display: "flex" }}>
                                                 <i
                                                   className="ethernetmacicon"
                                                   style={{ marginRight: "6px" }}
                                                 ></i>
                                                 <span style={{ textAlign: "left" }}>
                                                   <label className="radiolable">
                                                     Ethernet MAC
                                                   </label>
                                                   <br />
                                                   <span className="outdoor">
                                                   {nodeItemDt.ethernetMAC}
                                                   </span>
                                                 </span>
                                               </article>
                                             </article>
                                           </article>
                                           <article>
                                             <article className="sidebar2">
                                               <article style={{ display: "flex" }}>
                                                 <i
                                                   className="wirelessmacicon"
                                                   style={{ marginRight: "6px" }}
                                                 ></i>
                                                 <span style={{ textAlign: "left" }}>
                                                   <label className="radiolable">
                                                     Wireless MAC
                                                   </label>
                                                   <br />
                                                   <span className="outdoor">
                                                   {nodeItemDt.wirelessMAC}
                                                   </span>
                                                 </span>
                                               </article>
                                             </article>
                                           </article>
                                           
                                           <article>
                                             <article className="sidebar2">
                                               <article style={{ display: "flex" }}>
                                                 <i className="staioncicon"></i>
                                                 <span style={{ textAlign: "left" }}>
                                                   <label className="radiolable">
                                                     Station
                                                   </label>
                                                   <br />
                                                   <span className="outdoor">
                                                   {nodeItemDt.station}
                                                   </span>
                                                 </span>
                                               </article>
                                             </article>
                                           </article>
                                         </article>
                                       </article>
                                     </article>
                                   </article>
                                 </article>
                               </article>
                             </article>
           
                             <article className="col-md-8" style={{background:'white',marginLeft:'10px'}}>
                               <article
                                 style={{
                                    maxWidth:'450px',
                                    minWidth:'770px',
                                   margin:'auto',
                                   backgroundColor: "white",
                                   marginTop:'70px'
                                 }}
                               >
                                 <NetworkMonitoringDashboard nodeDataId={nodeDataId}/>
                               </article>
                             </article>
                           </article>
                         </article>   
                          
            </article>
          </article> */}
        </article>
      </section>
    </>
  );
};

export default NodeDetails;
