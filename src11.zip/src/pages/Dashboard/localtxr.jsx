import React, { useEffect, useRef, useState } from "react";
 import { format } from 'date-fns'

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "recharts";

const TxChart = ({graphOption,graphOptionValue}) => {
 const [snrData, setSnrData] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState({ status: false, msg: "" });
 const counterRef = useRef(1);

  const formatChartData = (apiData) => {
  const { timestamps, labels, columns } = apiData;

  return timestamps.map((timestamp, index) => {
    return {
      // timestamp: new Date(timestamp).toLocaleTimeString(), 
         timestamp: timestamp, 
      [labels[0]]: parseFloat(columns[0].values[index]),   
      [labels[1]]: parseFloat(columns[1].values[index])    
    };
  });
};


  const repalceItem = (newItem) => {
    setSnrData(prev => [...prev.slice(1), newItem])
  }




  const getServerStatusDt = async (url) => {
    setIsLoading(true);
    setIsError({ status: false, msg: "" });
    try {
      const username = "admin";
      const password = "admin";
      const token = btoa(`${username}:${password}`);
      const options = {
        method: "GET",
        headers: {
          "Authorization": `Basic ${token}`,
          "Content-Type": "application/json",
        },
      };

      const response = await fetch(url, options);

      if (response.status === 200) {
        const data = await response.json();
          
         if (graphOption === 'live') {
           let dt = new Date();
          const dataNew = {
            txrate: data.localtx,
            remtexrate: data.remotetx,
            timestamp: dt.getTime(),
            index: counterRef.current
          }
          repalceItem(dataNew)

          if (counterRef.current > 36) {
            counterRef.current = 1;
          }
          counterRef.current += 1;
            
        }else{
         const formatted = formatChartData(data);
        setSnrData(formatted);
        }

      } else if (response.status === 304) {
        console.log("304 Not Modified – using cached data.");
      } else {
        throw new Error(`Unexpected response: ${response.status}`);
      }
    } catch (error) {
      setIsError({ status: true, msg: error.message });
      console.error("Fetch error:", error);
    } finally {
      setIsLoading(false);
    }
  };


   useEffect(() => {
    if (graphOption === 'live') {
      const defData = []
      for (let i = 0; i < 37; i++) {
        let arr = { "timestamp": 0, "index": i, "rtt": 0 }
        if (i == 0) {
          arr = { "timestamp": 0, "index": i, "rtt": 0 }
        } else if (i % 12 == 0) {
          arr = { "timestamp": 0, "index": i, "rtt": 0 }
        }
        defData.push(arr);
      }
      setSnrData(defData)
    }
    let interval;
    if (graphOption === 'live') {
      interval = setInterval(() => {
        const url = 'http://localhost:8980/metronms/api/v2/nodelinks/txlive?nodeId=1';
        getServerStatusDt(url);
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [graphOption]); 

useEffect(() => {
  let url = '';
  if (graphOption === 'live') {
    url='http://localhost:8980/metronms/api/v2/nodelinks/txlive?nodeId=1';
  } else {
     url = `http://localhost:8980/metronms/rest/measurements/node%5B90%5D.worpindex%5B1.1%5D?aggregation=AVERAGE&att=txrate,remtexrate&duration=${graphOptionValue} `;
  }
  getServerStatusDt(url);
}, [graphOptionValue, graphOption]); 


  const hourFormat = (graphOption) => {
    //debugger;
    if (graphOption === 'onehour') {
      return 'HH:mm';
    } else if (graphOption === 'oneday') {
      return 'HH:mm';
    } else if (graphOption === 'oneweek') {
      return 'MMM/dd HH:mm';
    } else if (graphOption === 'onemonth') {
      return 'MMM dd';
    } else {
      return 'HH:mm:ss';
    }
  };

 const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${label} : ${payload[0].value}`}</p>
        <p className="label">{`${label} : ${payload[0].payload.timestamp}`}</p>
        <div>{format(new Date(payload[0].payload.timestamp),'HH mm')}</div>
        {payload.map((pld) => (
          <div style={{ display: "inline-block", padding: 10 }}>
            <div style={{ color: pld.fill }}>{pld.value}</div>
            <div>{pld.dataKey}</div>
          </div>
        ))}
      </div>
    );
  }

  return null;
};

  return (
   <>
      <article>
        <ResponsiveContainer width={700} height={240}>
                      <AreaChart data={snrData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis
                        //type="number"
                         dataKey="timestamp"
                        tickFormatter={(timestamp) => format(new Date(timestamp), hourFormat(graphOption))}
                          fontFamily="Lato-Regular"
                          letterSpacing="0.2px"
                          orientation="bottom"
                        />
                        {/* <XAxis
                        orientation="bottom"
                          dataKey="name"
                          reversed
                          fontFamily="Lato-Regular"
                          letterSpacing="0.2px"
                        /> */}
                        <YAxis ticks={[0, 0.1, 0.2, 0.3, 0.4, 0.5]} />
                        <Tooltip  content={<CustomTooltip />} cursor={{ fill: "transparent" }}/>
                        <Legend  />
                        <Area
                          type="monotone"
                           dataKey='remtexrate'
                          name="Local Tx"
                          stroke="#e39c56"
                          fill="#569de3"
                        />
                        <Area
                          type="monotone"
                          name="Remote Tx"
                            dataKey="txrate"
                          stroke="#3fc5e1"
                          fill="#e39c56"
                        />
                       
                        
                      </AreaChart>
                    </ResponsiveContainer>
        </article>  
   </>
  );
};

export default TxChart;

