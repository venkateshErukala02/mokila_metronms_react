import React, { useState, useEffect } from "react";
import LeftNavList from "../Navbar/leftnavpage";
import { useSelector } from 'react-redux';
import '../ornms.css';
import './../Inventory/inventory.css';
// data={
//   "count": 5,
//   "totalCount": 5,
//   "offset": 0,
//   "node": [
//     {
//       "lsnr": "72/73",
//       "lastpoll": 1743231727530,
//       "region": "asdasdf",
//       "city": "DefaultCity",
//       "opMode": "11ac",
//       "location": "Default",
//       "facility": "DefaultFacility",
//       "bandwidth": "HT20",
//       "macAddress": "1c:82:59:b0:8e:5d",
//       "frequency": 5220,
//       "primaryIP": "192.168.1.10",
//       "provisioned": true,
//       "sysObjectId": ".1.3.6.1.4.1.52619",
//       "sysName": "Sify",
//       "hasFlows": false,
//       "sysDescription": "API-18-5G-AC2x2-W2 - PTMP - 3.3 ( 230225 )",
//       "sysLocation": "location",
//       "sysContact": "1234567890",
//       "ssid": "SifySMAC3_PTMP",
//       "wifiMacAddress": "1c:82:59:b0:8e:5f",
//       "radioMode": "ap",
//       "channel": 44,
//       "remotePartners": 4,
//       "baseStationId": "aa-bbb-ccc-D1-ef",
//       "sysUptime": 289201874,
//       "disctaskId": 1,
//       "assetRecord": {
//         "customerName": "CustomerName",
//         "linkId": "0",
//         "elevation": "-",
//         "backupIp": "10.0.0.1",
//         "manufacturer": null,
//         "vendor": null,
//         "modelNumber": "API-18-5G-AC2x2-W2",
//         "circuitId": null,
//         "assetNumber": null,
//         "operatingSystem": null,
//         "rack": null,
//         "slot": null,
//         "division": null,
//         "department": null,
//         "firmware": "3.3(230225)",
//         "ethernetSpeed": "1000Mb/s",
//         "ioBandwidthLimit": "1734000",
//         "modulation": null,
//         "pointx": null,
//         "pointy": null,
//         "admin": null,
//         "additionalhardware": null,
//         "inputpower": null,
//         "numpowersupplies": null,
//         "hdd6": "-NA-",
//         "hdd5": "-NA-",
//         "hdd4": "-NA-",
//         "hdd3": "-NA-",
//         "hdd2": "0",
//         "hdd1": "-1",
//         "storagectrl": null,
//         "country": "5Ghz",
//         "vmwareManagedEntityType": null,
//         "vmwareManagedObjectId": null,
//         "vmwareManagementServer": null,
//         "vmwareState": null,
//         "vmwareTopologyInfo": null,
//         "port": null,
//         "category": "Unspecified",
//         "password": null,
//         "id": 10,
//         "description": null,
//         "building": null,
//         "floor": null,
//         "room": null,
//         "vendorPhone": null,
//         "vendorFax": "example@mail.com",
//         "vendorAssetNumber": null,
//         "lastModifiedBy": "",
//         "lastModifiedDate": 1740565576822,
//         "dateInstalled": null,
//         "lease": null,
//         "leaseExpires": null,
//         "supportPhone": null,
//         "maintcontract": null,
//         "maintContractNumber": null,
//         "maintContractExpiration": null,
//         "displayCategory": null,
//         "notifyCategory": null,
//         "pollerCategory": null,
//         "thresholdCategory": null,
//         "enable": null,
//         "autoenable": null,
//         "cpu": "34.26",
//         "ram": "59",
//         "snmpcommunity": null,
//         "rackunitheight": null,
//         "managedObjectInstance": null,
//         "managedObjectType": null,
//         "username": null,
//         "region": null,
//         "connection": null,
//         "comment": null,
//         "serialNumber": "20ATC0305022"
//       },
//       "ipConfig": {
//         "vlanStatus": 1,
//         "dhcpServerStatus": 1,
//         "vlanoption": null,
//         "id": 12,
//         "wirelessNetMask": "255.255.255.0",
//         "primaryDns": "0.0.0.0",
//         "secondaryDns": null,
//         "gateway": "192.168.1.10",
//         "networkMode": 1,
//         "addressType": "static",
//         "wirelessIpAddress": "192.168.1.10",
//         "ipAddress": "192.168.1.10",
//         "netMask": "255.255.255.0"
//       },
//       "vlanConfig": {
//         "id": 14,
//         "status": null,
//         "managementId": null,
//         "accessId": null,
//         "trunkOptionId": null,
//         "trunkId": null,
//         "svlanId": null,
//         "svlanEtherType": null,
//         "mode": null
//       },
//       "radioConfig": {
//         "acsStatus": false,
//         "dcsStatus": true,
//         "ddrsStatus": false,
//         "linkProfileRate": 192,
//         "atpcStatus": false,
//         "transmitPower": 5,
//         "rxPercent": 0,
//         "security": "psk2+ccmp-256",
//         "throughput": "0.23",
//         "upLimit": 867000,
//         "downLimit": 867000,
//         "mcsIndex": 19,
//         "trafficShapping": 0,
//         "id": 13,
//         "distance": null,
//         "suService": 1,
//         "macAclStatus": "disable"
//       },
//       "createTime": 1740565576334,
//       "categories": [],
//       "label": "192.168.1.10",
//       "foreignSource": null,
//       "active": true,
//       "foreignId": null,
//       "lastCapsdPoll": 1742378546652,
//       "labelSource": "A",
//       "type": "A",
//       "flocation": "DefaultLocation",
//       "productcode": "PtMP",
//       "netBIOSName": "up",
//       "ethernet": {
//         "inactivity": 5,
//         "mtu": 9000,
//         "id": 11,
//         "cableLength": 1,
//         "mode": 0
//       },
//       "id": "1"
//     }
//   ]
// }

const InventRpt = () => {
    const [isDropdownOpen, setDropdownOpen] = useState(false);
    const isVisible = useSelector(state => state.visibility.isVisible);

    const [invenData, setInvenData] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isError, setIsError] = useState({ status: false, msg: "" });
    const [success, setSuccess] = useState('');
    const [selectedRows, setSelectedRows] = useState([]);



    const getDataInvety = async () => {
        setIsLoading(true);
        setIsError({ status: false, msg: "" });
        try {
            const username = 'admin';
            const password = 'admin';
            const token = btoa(`${username}:${password}`)
            const url = 'api/v2/nodes?_s=&limit=25&offset=0&order=asc&orderBy=id';


            const options = {
                method: "GET",
                headers: {
                    'Authorization': `Basic ${token}`,
                    "Content-Type": "application/json",
                },
          

            };
            const response = await fetch(url, options);

            const data = await response.json();




            if (response.ok) {
                setIsLoading(false);
                setInvenData(data);
                setIsError({ status: false, msg: "" });
            } else {
                throw new Error("data not found");
            }
        } catch (error) {
            setIsLoading(false);
            setIsError({ status: true, msg: error.message });
        }
    };

    useEffect(() => {
        // getDataInvety();
            // const intervalId = setInterval(()=>{
                getDataInvety()
            // },1000);
        //   return ()=> clearInterval(intervalId);
    }, []);

    let activeTrueCount = 0;
    let activeFalseCount = 0;

    if (Array.isArray(invenData.node)) {
        invenData.node.forEach(device => {
            if (device.active === true) {
                activeTrueCount++;
            } else if (device.active === false) {
                activeFalseCount++;
            }
        });
    };

    const formatTime = (timestamp) => {
        const date = new Date(timestamp);
        const hours = date.getUTCHours().toString().padStart(2, '0');
        const minutes = date.getUTCMinutes().toString().padStart(2, '0');
        const seconds = date.getUTCSeconds().toString().padStart(2, '0');
        const milliseconds = date.getMilliseconds().toString().padStart(2, '0');
        return `${hours}:${minutes}:${seconds}.${milliseconds}`;
    };


    // const handleDelete = async(idToDelete) => {
    //         const requestBody = {
    //            nodeCheck : idToDelete,
    //            nodeData : idToDelete
    //         };

    //         try {
    //             const response = await fetch("admin/deleteSelNodes", {
    //                 method: "POST",
    //                 headers: {
    //                     "Content-Type": "application/json",
    //                 },
    //                 body: JSON.stringify(requestBody),
    //             });
    //             if (response.ok) {
    //                 setSuccess('Discovery started successfully');

    //             } else {
    //                 setIsError('Error starting discovery');
    //             }
    //         } catch (error) {
    //             console.error('Error:', error);
    //             setIsError('An error occurred while contacting the server.');
    //         } finally {
    //             setIsLoading(false); // Turn off loading state
    //         }

    //     }

    // const handleDelete = async (idToDelete) => {
    //     const formData = new FormData();
    //     formData.append("nodeCheck", idToDelete);
    //     formData.append("nodeData", idToDelete);

    //     try {
    //         const response = await fetch("admin/deleteSelNodes", {
    //             method: "POST",
    //             body: formData, // Note: Do NOT set Content-Type here
    //         });

    //         if (response.ok) {
    //             setSuccess("Node deleted successfully");

    //             // Update UI: Remove deleted item from table
    //             const updatedNodes = invenData.node.filter(node => node.id !== idToDelete);
    //             setInvenData(prev => ({
    //                 ...prev,
    //                 node: updatedNodes,
    //                 totalCount: updatedNodes.length
    //             }));
    //         } else {
    //             setIsError({ status: true, msg: "Error deleting node" });
    //         }
    //     } catch (error) {
    //         console.error("Error:", error);
    //         setIsError({ status: true, msg: "An error occurred while deleting node." });
    //     } finally {
    //         setIsLoading(false);
    //     }
    // };


    const getNodeIdsBySelectedIPs = () => {
        if (!Array.isArray(invenData.node)) return [];
        return invenData.node
            .filter((node) => selectedRows.includes(node.ipConfig.ipAddress))
            .map((node) => node.id);
    };


    const handleBulkDelete = async () => {


        const idsToDelete = getNodeIdsBySelectedIPs();

        if (idsToDelete.length === 0) {
            alert("No rows selected to delete.");
            return;
        }

        const bodyData = new URLSearchParams();
        idsToDelete.forEach((id) => {
            bodyData.append("nodeCheck", id);
            bodyData.append("nodeData", id);
        });
        // const bodyData = new URLSearchParams();
        // bodyData.append("nodeCheck", idToDelete);
        // bodyData.append("nodeData", idToDelete);

        try {
            const response = await fetch("admin/deleteSelNodes", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: bodyData.toString()
            });

            if (response.ok) {
                setSuccess("Node deleted successfully");
                alert('Node deleted successfully');
                const updatedNodes = invenData.node.filter(node => node.id !== idsToDelete);
                setInvenData(prev => ({
                    ...prev,
                    node: updatedNodes,
                    totalCount: updatedNodes.length
                }));
                setSelectedRows([])

            } else {
                setIsError({ status: true, msg: "Error deleting node" });
            }
        } catch (error) {
            console.error("Error:", error);
            setIsError({ status: true, msg: "An error occurred while deleting node." });
        } finally {
            setIsLoading(false);
        }
    };





    const handleSelectAll = () => {
        const allKeys = invenData.node.map((node) => node.ipConfig.ipAddress);
        if (selectedRows.length === invenData.node.length) {
            setSelectedRows([]);
        } else {
            setSelectedRows(allKeys);
        }
    };

    const handleCheckboxChange = (key) => {
        setSelectedRows((prevSelected) =>
            prevSelected.includes(key)
                ? prevSelected.filter((rowKey) => rowKey !== key)
                : [...prevSelected, key]
        );
    };





    const toggleDropdown = () => {
        setDropdownOpen(!isDropdownOpen);
    };

    return (
        <>
            <article className="display-f">
            <LeftNavList className="leftsidebar"/>
                    <article className="container-fluid">
                    <article className="row">
                    <article className="col-md-12">
                        <h1 className="inventtitle">Inventory Reports</h1>

                        <article className="row custom-row border-allsd">
                            <article className="col-md-7">
                                <button className="clearfix arrowlf">
                                    <i className="fa-solid fa-arrow-left"></i>
                                </button>
                                <button className="clearfix numcl"><span>1</span></button>
                                <button className="clearfix arrowlf"><i className="fa-solid fa-arrow-right"></i></button>
                                <span className="eventscp">Scope : </span>
                                <span className="eventgolcl" onClick={toggleDropdown}  >Golbal <span class="fa fa-chevron-down highlightText v-align-tt iconsy"></span></span>

                                <span className="totalcl" style={{ marginLeft: '10px' }}>Total: <span>{invenData.totalCount}</span></span>
                                <span className="totalcl">Good: <span>{activeTrueCount}</span></span>
                                <span className="totalcl">Down: <span>{activeFalseCount}</span></span>
                                <input type="text" style={{ marginRight: '10px' }} name="" placeholder="IP Address / System Name / Serial Number" id="" className="form-controlinventory" />
                                <button className="clearfix createbtn">Search</button>

                            </article>
                            <article className="col-md-5">
                                <article style={{ float: 'right' }}>
                                    <ul className="inventorylist">

                                        <li>
                                            <label htmlFor="" className="selectlbl">Select Columns  <span style={{ marginTop: '2px' }} className="glyphicon glyphicon-tasks"></span></label>
                                        </li>
                                        <li>
                                            <button className="clearfix createbtn" onClick={handleBulkDelete}>Delete
                                                <i className="fa fa-trash" aria-hidden="true"></i>
                                            </button>

                                        </li>
                                        <li>
                                            <button className="clearfix createbtn">Inventory Report
                                                <i className="fa fa-file-text" aria-hidden="true"></i>
                                            </button>

                                        </li>
                                        <li>
                                            <button className="clearfix createbtn">Node Report
                                                <span className="fa fa-file-pdf-o"></span>
                                            </button>

                                        </li>
                                        <li>
                                            <select className="form-controll1" value="select" style={{ maxWidth: '58px', minWidth: '58px', marginTop: '2px', fontSize: '12px' }} aria-invalid="false">
                                                <option value="0" label="100">100</option>
                                                <option value="1" label="25" defaultValue={25}>25</option>
                                                <option value="2" label="50">50</option>
                                                <option value="3" label="100">100</option>
                                            </select>
                                        </li>
                                    </ul>

                                </article>
                            </article>
                        </article>


                        <article className="row border-lr" style={{height:'80vh'}}>
                            <table className="col-md-12" style={{ height: '0vh' }}>
                                <thead className="inventthtb">
                                    <tr style={{ textAlign: 'center' }}>
                                        <th><input type="checkbox" className="incl"
                                            onChange={handleSelectAll}
                                            checked={
                                                Array.isArray(invenData.node) &&
                                                invenData.node.length > 0 &&
                                                selectedRows.length === invenData.node.length
                                            }
                                        /></th>
                                        <th>System Name</th>
                                        <th>Primary IP</th>
                                        <th>Up Time</th>
                                        <th>Device Type</th>
                                        <th>Line</th>
                                        <th>Station</th>
                                        <th>Position</th>
                                        <th>Action</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody className="inventbdtb">
                                    {Array.isArray(invenData.node) && invenData.node.length > 0 ? (
                                        invenData.node.map((event) => (
                                            <tr key={event.id} style={{ textAlign: 'center' }}>
                                                <td><input type="checkbox" className="incl"
                                                    checked={selectedRows.includes(event.ipConfig.ipAddress)}
                                                    onChange={() => handleCheckboxChange(event.ipConfig.ipAddress)}
                                                /></td>
                                                <td style={{ width: "px" }}>{event.sysName}</td>
                                                <td style={{ width: 'px' }}>{event.ipConfig.ipAddress}</td>
                                                <td style={{ width: '' }}>{formatTime(event.sysUptime)}</td>
                                                <td style={{ width: '' }}>{event.deviceType}</td>
                                                <td style={{ width: '' }}>{event.region}</td>
                                                <td style={{ width: '' }}>{event.facility}</td>
                                                <td style={{ width: '' }}>{event.radioMode}</td>
                                                <td><i className="fa fa-sync"></i></td>
                                                <td><i className="fa fa-trash" onClick={handleBulkDelete} ></i></td>

                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan="12" className="datacl centered-text">No Data</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </article>



                    </article>
                    </article>
                </article>
            </article>
        </>

    )
}
export default InventRpt;