import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";

const TcEventTab=()=>{


const location = useLocation();
const nodeData = location.state?.node;
useEffect(() => {
  }, [nodeData]);



    return(
        <h1>Eventab</h1>
    )
}
export default TcEventTab;