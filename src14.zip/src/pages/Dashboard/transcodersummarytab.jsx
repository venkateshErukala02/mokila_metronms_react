import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import nodeimage from "../../assets/img/suinodeview.png";
import radioimage from "../../assets/img/radiomode.png";
import ptmplinkimage from "../../assets/img/PTMPlink.png";
import bootloader from "../../assets/img/bootloader.png";
import NetworkMonitoringDashboard from "./nodeviewchart";
import LatencyChart from "./latencychart";
import TranscoderDashboard from "./transcoderdashboard";


const TcSummaryTab = ({ transcoderData }) => {

    // console.log('hhhhhhhh',nodeDataId);


     const [isLoading, setIsLoading] = useState("");
       const [isError, setIsError] = useState("");
      const [upTimeData, setUpTimeData] = useState([]);
    //    const count = useSelector((state) => state);
    //    const isVisible = useSelector((state) => state.visibility.isVisible);
    //    const [currentTab,setCurrentTab] = useState('summary');
 



      const getServerStatusDt = async (url) => {
         setIsLoading(true);
         setIsError({ status: false, msg: "" });
         try {
           const username = "admin";
           const password = "admin";
           const token = btoa(`${username}:${password}`);
           const options = {
             method: "GET",
             headers: {
               "Authorization": `Basic ${token}`,   
               "Content-Type": "application/json",
             },
           };
           const response = await fetch(url);
           const data = await response.json();

           if (response.ok) {
             setIsLoading(false);


             setUpTimeData(data);
             console.log("Fetched server status:", data);
             setIsError({ status: false, msg: "" });
           } else {
             throw new Error("Data not found");
           }
         } catch (error) {
           setIsLoading(false);
           setIsError({ status: true, msg: error.message });
           console.error("Fetch error:", error);
         }
       };

       useEffect(() => {
         const fetchData = async () => {
           let url = 'http://192.168.66.24:8084/transcoder/api/v1/uptime';
           await getServerStatusDt(url);
         };
         fetchData();
       }, []);

      

    const nodeLocation = useSelector((state) => state.node.node.location) || localStorage.getItem('nodeLocation');
const nodeIpaddress = useSelector((state) => state.node.node.ipAddress) || localStorage.getItem('nodeIpaddress');
    return (
        <>

            <article className="row">
                <article
                    className="col-md-12"
                    style={{ padding: "10px", backgroundColor: "#cccccc" }}
                >

                    <article className="container-fluid">
                        <article className="row" style={{ display: "flex" }}>
                            <article className="col-md-2 nodelistheight" id="summary-1 div1">
                                <article>

                                    <article className="" id="div2">
                                        <article style={{ margin: "auto", textAlign: 'center' }}>
                                            <img className="nodeimg" src={nodeimage} alt="node" />
                                            <label class="summarymode"> {transcoderData?.System?.ser}</label>
                                            <label class="summarymode" style={{ display: 'block' }}> {nodeLocation} ({transcoderData?.System?.sysname})</label>
                                            <label class="summarysytem"><i class="fas fa-arrow-up fa-1x ng-scope "></i>{upTimeData}</label>
                                        </article>
                                        <article style={{ margin: "auto" }}>
                                            <article>
                                                <article style={{ margin: "auto" }}>
                                                    <article>
                                                        <article>

                                                        </article>
                                                    </article>
                                                </article>
                                            </article>

                                            <ul className="summarylist">
                                                <li>
                                                    <img
                                                        src={radioimage}
                                                        alt=""
                                                        style={{ marginRight: "6px" }}
                                                    />
                                                    <h6>NTP <span>{transcoderData?.System?.sntpip} </span></h6>
                                                </li>
                                                {/* <li>   <img
                          src={ptmplinkimage}
                          alt="PTMP"
                          style={{ marginRight: "6px" }}
                        /> <h6>Link Type  <span className="">{nodeItemDt[0]?.linkType}</span></h6></li> */}
                                                <li>
                                                    <i
                                                        className="hardwareversionicon"
                                                        style={{ marginRight: "6px" }}
                                                    ></i>
                                                    <h6>Hardware Version <span>{transcoderData?.System?.hardware}</span></h6>
                                                </li>
                                                <li>  <img
                                                    src={bootloader}
                                                    alt=""
                                                    style={{
                                                        width: "35px",
                                                        height: "35px",
                                                        marginRight: "6px",
                                                    }}
                                                />
                                                    <h6> Firmware Version <span>{transcoderData?.System?.firmware} </span></h6></li>


                                            </ul>

                                        </article>
                                    </article>
                                </article>
                            </article>

                            <article className="col-md-10" style={{ background: 'white', borderLeft: '10px solid #cccccc' }}>
                                <article
                                    style={{
                                        backgroundColor: "white",

                                    }}
                                >
                                    <article className="container-fluid">
                                        <article className="row">
                                            <article className="col-4 col-md-4 quadcont">
                                                <h1 className="quadhead">Quad</h1>
                                                < article className="">
                                                    <article className="card-sub">
                                                        <article class="form-row"><label for="" class="col-4 quadlis">Bitrate</label><article class="col-sm-4 col-md-4 col-lg-5 quadlisvalue">
                                                            {transcoderData?.Quad?.bitrate}
                                                        </article>
                                                        </article>
                                                        <article class="form-row"><label for="" class="col-4 quadlis">Profile</label><article class="col-sm-4 col-md-4 col-lg-5 quadlisvalue">
                                                            {transcoderData?.Quad?.profile}
                                                        </article>
                                                        </article>
                                                        <article class="form-row"><label for="" class="col-4 quadlis">Xpos</label><article class="col-sm-4 col-md-4 col-lg-5 quadlisvalue">
                                                            {transcoderData?.Quad?.xpos}
                                                        </article>
                                                        </article>
                                                        <article class="form-row"><label for="" class="col-4 quadlis">Ypos</label><article class="col-sm-4 col-md-4 col-lg-5 quadlisvalue">
                                                            {transcoderData?.Quad?.ypos}
                                                        </article>
                                                        </article>
                                                    </article>
                                                </article>
                                            </article>
                                            <article className="col-8 col-md-8 rstcont">
                                                <h1 className="quadhead">RSTPURL</h1>
                                                < article className="">
                                                    <article className="card-sub">
                                                        <article class="form-row"><label for="" class="col-3 quadlis">Cam1URL</label><article class="col-sm-9 col-md-9 col-lg-9 quadlisvalue">
                                                            
                                                            {transcoderData?.RSTPURL?.["cam1.url"]}

                                                        </article>
                                                        </article>
                                                        <article class="form-row"><label for="" class="col-3 quadlis">Cam2URL</label><article class="col-sm-9 col-md-9 col-lg-9 quadlisvalue">
                                                          {transcoderData?.RSTPURL?.["cam2.url"]}
                                                        </article>
                                                        </article>
                                                        <article class="form-row"><label for="" class="col-3 quadlis">Cam3URL</label><article class="col-sm-9 col-md-9 col-lg-9 quadlisvalue">
                                                           {transcoderData?.RSTPURL?.["cam3.url"]}
                                                        </article>
                                                        </article>
                                                        <article class="form-row"><label for="" class="col-3 quadlis">Cam4URL</label><article class="col-sm-9 col-md-9 col-lg-9 quadlisvalue">
                                                            {transcoderData?.RSTPURL?.["cam4.url"]}
                                                        </article>
                                                        </article>
                                                    </article>
                                                </article>
                                            </article>
                                        </article>
                                    </article>

                                    <TranscoderDashboard/>
                                    
                                </article>
                            </article>
                        </article>
                    </article>

                </article>
            </article>
        </>
    )
}

export default TcSummaryTab;