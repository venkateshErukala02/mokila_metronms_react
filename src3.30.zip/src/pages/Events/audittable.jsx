import React,{useState,useEffect} from "react";



const AuditTable=()=>{
    return(

        <>
          <article className="eventmaintable">
                <article className="row">
                    <table className="col-12">
                        <thead className="eventsthtb">
                            <tr>

                                <th>Date</th>
                                <th>Type</th>
                                <th>User</th>
                                <th>Log</th>
                            </tr>
                        </thead>
                        <tbody className="eventstbdtb">
                            {Array.isArray(eventmainData) && eventmainData.length > 0 ? (
                                eventmainData.map((event) => (
                                    <tr key={event.id}>
                                        <td>{event.date}</td>
                                        <td>{event.type}</td>
                                        <td>{event.user}</td>
                                        <td>{event.log}</td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="4" className="datacl centered-text">No Data</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </article>
            </article>
        </>
    )
}

export default AuditTable;