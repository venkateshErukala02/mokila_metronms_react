import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";

const SnEventTab=()=>{


const location = useLocation();
const nodeData = location.state?.node;
useEffect(() => {
  }, [nodeData]);



    return(
        <h1>Eventab</h1>
    )
}
export default SnEventTab;